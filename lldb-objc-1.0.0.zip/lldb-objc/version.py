#!/usr/bin/env python3
"""
Version information for LLDB Objective-C Tools.
"""

__version__ = "1.0.0"
__author__ = "Alan"
__description__ = "LLDB commands for Objective-C method introspection and debugging"
